let index = 0;
const books = document.querySelectorAll(".book");

function updateSlider() {
    books.forEach((b, i) => {
        b.classList.remove("active");
        if (i === index) b.classList.add("active");
    });
}

document.getElementById("next").onclick = () => {
    index = (index + 1) % books.length;
    updateSlider();
};

document.getElementById("prev").onclick = () => {
    index = (index - 1 + books.length) % books.length;
    updateSlider();
};

updateSlider();
