<?php
include "connect.php";
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success'=>false, 'message'=>'Invalid request']);
    exit;
}

$issued_id = isset($_POST['issued_id']) ? (int)$_POST['issued_id'] : 0;
if ($issued_id <= 0) {
    echo json_encode(['success'=>false, 'message'=>'Invalid id']);
    exit;
}

// 1. Get issued record to find which book it is
$res = mysqli_query($conn, "SELECT * FROM issued_books WHERE id = $issued_id LIMIT 1");
if (!$res || mysqli_num_rows($res) == 0) {
    echo json_encode(['success'=>false, 'message'=>'Issued record not found']);
    exit;
}
$rec = mysqli_fetch_assoc($res);
$book_id = (int)$rec['book_id'];

// 2. Mark as returned (Update return_date instead of action)
$upd = "UPDATE issued_books SET return_date = NOW() WHERE id = $issued_id";
if (!mysqli_query($conn, $upd)) {
    echo json_encode(['success'=>false, 'message'=>'Could not update database']);
    exit;
}

// 3. Increase book quantity back
$inc = "UPDATE books SET qty = qty + 1 WHERE id = $book_id";
mysqli_query($conn, $inc); 

echo json_encode(['success'=>true, 'message'=>'Book marked as returned']);
exit;
?>