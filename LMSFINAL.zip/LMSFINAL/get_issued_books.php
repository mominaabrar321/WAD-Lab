<?php
include "connect.php";

// Fetch data joining Users and Books tables
$sql = "SELECT ib.id, u.name AS user, b.title AS book, ib.issue_date, ib.due_date, ib.return_date
        FROM issued_books ib
        LEFT JOIN users u ON ib.user_id = u.user_id
        LEFT JOIN books b ON ib.book_id = b.id
        ORDER BY ib.id ASC";

$result = mysqli_query($conn, $sql);
$issued_books = [];

// --- CONFIGURATION ---
$fine_per_day = 10; // Amount to charge per late day
date_default_timezone_set('Asia/Karachi'); // Set timezone to ensure accurate 'today' calculation
// ---------------------

while($row = mysqli_fetch_assoc($result)){
    
    // Calculate Fine based on Dates ONLY (ignoring time)
    $due = new DateTime($row['due_date']);
    $due->setTime(0,0,0); // Reset time to start of day

    if ($row['return_date'] == NULL) {
        // Book Not Returned Yet
        $action_html = "<button class='return-btn' onclick='returnIssued(".$row['id'].")'>Return</button>";
        
        $now = new DateTime(); // Today's date
        $now->setTime(0,0,0); // Reset time to start of day
        
        if($now > $due) {
            $diff = $now->diff($due);
            $days_late = $diff->days;
            $fine_amount = $days_late * $fine_per_day;
            $fine_html = "<span style='color:red; font-weight:bold;'>Rs. $fine_amount</span>";
        } else {
            $fine_html = "Rs. 0";
        }

    } else {
        // Book WAS Returned
        $action_html = "<span style='color:green; font-weight:bold;'>Returned</span>";
        
        $returned = new DateTime($row['return_date']);
        $returned->setTime(0,0,0); // Reset time to start of day
        
        if($returned > $due) {
            $diff = $returned->diff($due);
            $days_late = $diff->days;
            $fine_amount = $days_late * $fine_per_day;
            $fine_html = "<span style='color:red;'>Rs. $fine_amount (Paid)</span>";
        } else {
            $fine_html = "Rs. 0";
        }
    }

    $issued_books[] = [
        'id' => $row['id'],
        'user' => $row['user'] ?? 'Unknown User',
        'book' => $row['book'] ?? 'Unknown Book',
        'issue_date' => date('Y-m-d', strtotime($row['issue_date'])),
        // Format date nicer for display
        'due_date' => date('Y-m-d', strtotime($row['due_date'])),
        'fine' => $fine_html,
        'action' => $action_html
    ];
}

echo json_encode($issued_books);
?>