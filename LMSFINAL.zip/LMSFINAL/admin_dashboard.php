<?php
session_start();
include 'connect.php';

// SECURITY CHECK: Kick out anyone who isn't the admin
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.html");
    exit;
}

// Get Counts from Database for the dashboard
$book_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM books"))['c'];
$user_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM users"))['c'];
// Count books that haven't been returned yet
$issue_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM issued_books WHERE return_date IS NULL"))['c'];
?>