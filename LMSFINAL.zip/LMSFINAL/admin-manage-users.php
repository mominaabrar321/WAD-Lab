<?php
include "connect.php";

// Fetch all users
$query = "SELECT user_id, name, email FROM users ORDER BY user_id ASC";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Manage Users - Admin</title>
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <link rel="stylesheet" href="admin-manage-users.css" />
  <style>
    /* ================= THEME COLORS ================= */
    :root {
      --accent: #c47a42; /* Buttons / Header */
      --aside-bg: #e5d2bc;
      --aside-hover: #d9bea1;
      --aside-active: #c48d5b;
      --bg: #f6f6f6;
    }

    /* ================= GLOBAL ================= */
    body {
      font-family: Segoe UI, Arial;
      background: var(--bg);
      margin: 0;
      color: #222;
    }

    /* ================= LAYOUT ================= */
    .admin-layout {
      display: flex;
      min-height: 100vh;
    }

    /* ================= ASIDE ================= */
    .admin-aside {
      width: 210px;
      background: var(--aside-bg);
      padding: 18px;
      border-right: 1px solid #d8c4ac;
    }

    .admin-aside nav a {
      display: block;
      padding: 10px 12px;
      margin-bottom: 6px;
      color: #333;
      text-decoration: none;
      border-radius: 6px;
      transition: 0.3s;
    }

    .admin-aside nav a:hover {
      background: var(--aside-hover);
    }

    .admin-aside nav a.active {
      background: var(--aside-active);
      color: #fff;
    }

    /* ================= MAIN ================= */
    .admin-main {
      flex: 1;
      padding: 24px;
    }

    .admin-header h2 {
      margin-bottom: 20px;
    }

    /* ================= TABLE ================= */
    .admin-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 16px;
      background: #fff;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }

    .admin-table th,
    .admin-table td {
      padding: 12px 14px;
      border: 1px solid #aaa; /* Column lines */
      text-align: center;
    }

    .admin-table thead th {
      background: var(--accent);
      color: #fff;
      font-weight: 600;
    }

    /* Optional: alternating row colors */
    .admin-table tbody tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    /* Optional: hover effect */
    .admin-table tbody tr:hover {
      background-color: #f2e0d0;
    }

    /* ================= BUTTONS ================= */
    .btn-edit {
      background: var(--accent);
      color: #fff;
      padding: 6px 12px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      transition: 0.2s;
      text-decoration: none;
    }

    .btn-edit:hover {
      opacity: 0.85;
    }

    .btn-del {
      background: #e74c3c;
      color: #fff;
      padding: 6px 12px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      transition: 0.2s;
      text-decoration: none;
    }

    .btn-del:hover {
      background: #c0392b;
    }

  </style>
</head>
<body>
  <div class="admin-layout">
    <!-- Sidebar -->
    <aside class="admin-aside">
      <h3>Admin</h3>
      <nav>
        <a href="admin-dashboard.php">Dashboard</a>
        <a href="admin-manage-books.php">Manage Books</a>
        <a href="admin-add-book.html">Add Book</a>
        <a href="admin-manage-users.php" class="active">Manage Users</a>
        <a href="admin-issued-books.html">Issued Books</a>
        <a href="lms.html" target="_blank">Open Site</a>
        <a href="logout.php" id="admin-logout">Logout</a>
      </nav>
    </aside>

    <!-- Main -->
    <main class="admin-main">
      <header class="admin-header">
        <h2>Manage Users</h2>
      </header>

      <table class="admin-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          <?php if($result && mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)) : ?>
              <tr>
                <td><?= htmlspecialchars($row['user_id']) ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td>
                  <!-- Edit Button -->
                  <a href="admin-edit-user.php?id=<?= $row['user_id'] ?>" class="btn-edit">Edit</a>

                  <!-- Delete Button -->
                  <a href="admin-delete-user.php?id=<?= $row['user_id'] ?>" 
                     onclick="return confirm('Are you sure you want to delete this user?')"
                     class="btn-del">Delete</a>
                </td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr>
              <td colspan="4">No users found</td>
            </tr>
          <?php endif; ?>
        </tbody>

      </table>
    </main>
  </div>
</body>
</html>
