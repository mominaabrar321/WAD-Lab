<?php
include "connect.php";

// Get POST data
$title = trim($_POST['title']);
$author = trim($_POST['author']);
$category = trim($_POST['category']);
$qty = (int)$_POST['qty'];

// Check if book already exists (by title)
$checkQuery = "SELECT * FROM books WHERE title = '".mysqli_real_escape_string($conn, $title)."'";
$checkResult = mysqli_query($conn, $checkQuery);

if(mysqli_num_rows($checkResult) > 0){
    echo "<script>
            alert('This book already exists!');
            window.location.href = 'admin-add-book.html';
          </script>";
    exit();
}

// Handle image upload if provided
$imagePath = "";
if(isset($_FILES['image']) && $_FILES['image']['name'] != ""){
    $image = $_FILES['image'];
    $imageName = time().'_'.basename($image['name']); // unique name
    $targetDir = "images/";
    $targetFile = $targetDir . $imageName;

    // Optional: Validate image type
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    $validTypes = ['jpg','jpeg','png','gif'];
    if(in_array($imageFileType, $validTypes)){
        if(move_uploaded_file($image['tmp_name'], $targetFile)){
            $imagePath = $targetFile;
        } else {
            echo "<script>
                    alert('Failed to upload image!');
                    window.location.href = 'admin-add-book.html';
                  </script>";
            exit();
        }
    } else {
        echo "<script>
                alert('Invalid image type! Only JPG, JPEG, PNG, GIF allowed.');
                window.location.href = 'admin-add-book.html';
              </script>";
        exit();
    }
}

// Insert query
$sql = "INSERT INTO books (title, author, category, qty, image) VALUES (
    '".mysqli_real_escape_string($conn, $title)."',
    '".mysqli_real_escape_string($conn, $author)."',
    '".mysqli_real_escape_string($conn, $category)."',
    $qty,
    '".mysqli_real_escape_string($conn, $imagePath)."'
)";

if(mysqli_query($conn, $sql)) {
    echo "<script>
            alert('Book added successfully!');
            window.location.href = 'admin-manage-books.php';
          </script>";
    exit();
} else {
    echo "<script>
            alert('Error adding book: ".mysqli_error($conn)."');
            window.location.href = 'admin-add-book.html';
          </script>";
    exit();
}
?>
