<?php
include "connect.php";

$id = $_POST['id'];
$name = $_POST['name'];
$email = $_POST['email'];

$sql = "UPDATE users SET name='$name', email='$email' WHERE user_id=$id";

if (mysqli_query($conn, $sql)) {
    header("Location: admin-manage-users.php");
    exit;
} else {
    echo "Error updating user!";
}
?>