<?php
session_start();
include "connect.php";

$user_id = $_SESSION['user_id'] ?? 1; 
$book_id = $_POST['book_id'] ?? 0;
$days = (int)($_POST['days'] ?? 7); // Default to 7 days if missing

if(!$book_id){
    echo json_encode(['success'=>false, 'message'=>'Book ID missing']);
    exit;
}

// Check Qty
$res = mysqli_query($conn, "SELECT qty FROM books WHERE id='$book_id'");
$row = mysqli_fetch_assoc($res);

if(!$row || $row['qty'] <= 0){
    echo json_encode(['success'=>false, 'message'=>'Book not available (Out of Stock)']);
    exit;
}

// Calculate Due Date
$due_date = date('Y-m-d H:i:s', strtotime("+$days days"));

// Insert into issued_books with due_date
$sql = "INSERT INTO issued_books (user_id, book_id, issue_date, due_date) VALUES ('$user_id', '$book_id', NOW(), '$due_date')";

if(mysqli_query($conn, $sql)){
    // Decrement Quantity
    mysqli_query($conn, "UPDATE books SET qty = qty - 1 WHERE id='$book_id'");
    
    echo json_encode([
        'success'=>true, 
        'message'=>"Book issued successfully! Due on: " . date('d M Y', strtotime($due_date))
    ]);
} else {
    echo json_encode(['success'=>false, 'message'=>'Database Error: ' . mysqli_error($conn)]);
}
?>