<?php
session_start();
include 'connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Clean input
    $email = mysqli_real_escape_string($conn, trim($_POST['email'] ?? ''));
    $pass  = mysqli_real_escape_string($conn, trim($_POST['password'] ?? ''));

    if (empty($email) || empty($pass)) {
        echo "All fields are required! <a href='login.html'>Go Back</a>";
        exit;
    }

    // ============================================================
    // 1. ADMIN CHECK (Hardcoded specific email & password)
    // ============================================================
    if ($email === 'admin@gmail.com' && $pass === 'admin123') {
        
        // Set Admin Session
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['name'] = "Administrator"; 

        // Redirect to Admin Dashboard
        echo "
        <script>
            // Optional: Save admin marker to JS if needed
            sessionStorage.setItem('lms_current_user', JSON.stringify({ name: 'Admin', isAdmin: true }));
            window.location.href = 'admin-dashboard.php';
        </script>
        ";
        exit;
    }

    // ============================================================
    // 2. NORMAL USER CHECK (Database)
    // ============================================================
    $sql = "SELECT user_id, name, email, password FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);

        if ($user['password'] === $pass) {
            
            // Set User Session
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['name'] = $user['name'];

            // Save Login History
            $user_id = $user['user_id'];
            $log_sql = "INSERT INTO login_history (user_id) VALUES ('$user_id')";
            if (mysqli_query($conn, $log_sql)) {
                $_SESSION['current_log_id'] = mysqli_insert_id($conn);
            }

            // Prepare Data for JS
            $js_user_data = json_encode([
                'id' => $user['user_id'],
                'name' => $user['name'],
                'email' => $user['email'],
                'isAdmin' => false
            ]);

            // Redirect to User Home
            echo "
            <script>
                sessionStorage.setItem('lms_current_user', '$js_user_data');
                window.location.href = 'lms.html'; // or lms.html if you haven't renamed it
            </script>
            ";
            exit;

        } else {
            echo "Incorrect password! <a href='login.html'>Try Again</a>";
            exit;
        }
    } else {
        echo "Email not registered! <a href='signup.html'>Signup Here</a>";
        exit;
    }
}
?>