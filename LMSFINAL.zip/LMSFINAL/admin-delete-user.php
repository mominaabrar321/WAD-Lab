<?php
include "connect.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM users WHERE user_id = $id";

    if (mysqli_query($conn, $sql)) {
        header("Location: admin-manage-users.php");
        exit;
    } else {
        echo "Error deleting user!";
    }
}
?>