/* ================================
   ADMIN SCRIPT – LMS COMPLETE JS
   ================================ */

document.addEventListener("DOMContentLoaded", () => {
    
    // 1. Load Manage Books Table (if on that page)
    if (document.querySelector("#admin-books-table")) {
        loadAdminBooks();
    }

    // 2. Load Issued Books Table (THIS WAS MISSING)
    if (document.querySelector("#admin-issued-table")) {
        loadIssuedBooks();
    }

    // 3. Handle Add Book Form
    let addForm = document.getElementById("add-book-form"); // ID fixed to match your HTML
    if (addForm) {
        // Remove 'onsubmit' from HTML if using this listener, or rely on PHP action
        // Since we switched to PHP form submission, this JS listener isn't strictly needed 
        // unless you want to use AJAX. For now, let PHP handle the form.
    }

    // 4. Load User-side Books
    if (document.querySelector(".books-container")) {
        loadUserBooks();
    }
});

/* ----------------------------------------------------
   LOAD ISSUED BOOKS (Updated Columns & Fines)
   ---------------------------------------------------- */
function loadIssuedBooks() {
    fetch("get_issued_books.php")
        .then(res => res.json())
        .then(data => {
            const tbody = document.querySelector("#admin-issued-table tbody");
            tbody.innerHTML = "";

            if(data.length === 0) {
                // Colspan 6 for the 6 columns
                tbody.innerHTML = "<tr><td colspan='6' style='text-align:center;'>No books issued yet.</td></tr>";
                return;
            }

            data.forEach(row => {
                // NOTICE: row.action is now before row.fine
                const tr = `
                    <tr>
                        <td>${row.id}</td>
                        <td>${row.user}</td>
                        <td>${row.book}</td>
                        <td>${row.due_date}</td>
                        <td>${row.action}</td> 
                        <td>${row.fine}</td>
                    </tr>
                `;
                tbody.innerHTML += tr;
            });
        })
        .catch(err => console.error("Error loading issued books:", err));
}

/* ----------------------------------------------------
   HANDLE RETURN BOOK ACTION
   ---------------------------------------------------- */
function returnIssued(issuedId) {
    if(!confirm("Mark this book as returned?")) return;

    let formData = new FormData();
    formData.append('issued_id', issuedId);

    fetch("return_book.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            alert("Book Returned Successfully!");
            loadIssuedBooks(); // Refresh the table automatically
        } else {
            alert("Error: " + data.message);
        }
    })
    .catch(err => console.error("Error returning book:", err));
}

/* ----------------------------------------------------
   LOAD MANAGE BOOKS (Admin Panel)
   ---------------------------------------------------- */
function loadAdminBooks() {
    // If you are using the PHP file 'admin-manage-books.php' to display the table directly,
    // this JS function might not be needed. 
    // However, if you want to load it dynamically via AJAX, keep this.
    // For now, we will leave it as a placeholder or fetch from a JSON endpoint if you created one.
}

/* ----------------------------------------------------
   DELETE BOOK
   ---------------------------------------------------- */
function deleteBook(id) {
    if (!confirm("Are you sure you want to delete this book?")) return;

    fetch("admin_delete_book.php", { 
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "id=" + id
    })
    .then(res => res.text())
    .then(response => {
        if (response.trim() === "success") {
            location.reload(); // Reload page to see changes
        } else {
            alert("Delete failed: " + response);
        }
    })
    .catch(err => console.log("Error deleting book:", err));
}

/* ----------------------------------------------------
   LOAD USER BOOKS (Frontend)
   ---------------------------------------------------- */
function loadUserBooks() {
    const container = document.querySelector(".books-container");
    if (!container) return;

    fetch("get_books.php")
        .then(res => res.json())
        .then(books => {
            container.innerHTML = "";
            books.forEach(b => {
                container.innerHTML += `
                    <div class="book-card">
                        <img src="${b.image || 'images/default.jpg'}" alt="">
                        <h3>${b.title}</h3>
                        <p>${b.author}</p>
                        <button class="issue-btn">Issue Book</button>
                    </div>
                `;
            });
        })
        .catch(err => console.log("User books loading error:", err));
}