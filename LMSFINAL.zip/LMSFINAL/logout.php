<?php
session_start();
include 'connect.php';

// 1. Update Database (Save Logout Time)
if (isset($_SESSION['current_log_id'])) {
    $log_id = $_SESSION['current_log_id'];
    $sql = "UPDATE login_history SET logout_time = NOW() WHERE id = '$log_id'";
    mysqli_query($conn, $sql);
}

// 2. Destroy Server Session
session_unset();
session_destroy();

// 3. Clear Browser Memory and Redirect
echo "
<script>
    // Remove the user from the browser memory
    sessionStorage.removeItem('lms_current_user');
    
    // Redirect to login page
    window.location.href = 'login.html';
</script>
";
exit;
?>