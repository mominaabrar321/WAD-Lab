// ====================== PUBLIC SCRIPT ======================

// LocalStorage keys
const LS_BOOKS_KEY = "lms_books_v1";
const LS_USERS_KEY = "lms_users_v1";
const LS_ISSUED_KEY = "lms_issued_v1";

// ====================== SEED DATA ======================
function seedData() {
  if(!localStorage.getItem(LS_BOOKS_KEY)){
    const demo = [
      {id:1,title:"Harry Potter and the Sorcerer's Stone",author:"J.K. Rowling",category:"Fantasy",qty:4},
      {id:2,title:"The Alchemist",author:"Paulo Coelho",category:"Fiction",qty:3},
      {id:3,title:"Clean Code",author:"Robert C. Martin",category:"Programming",qty:2}
    ];
    localStorage.setItem(LS_BOOKS_KEY, JSON.stringify(demo));
  }
  if(!localStorage.getItem(LS_USERS_KEY)){
    const users = [
      {id:1,name:"Demo User",email:"user@example.com",password:"password"}
    ];
    localStorage.setItem(LS_USERS_KEY, JSON.stringify(users));
  }
  if(!localStorage.getItem(LS_ISSUED_KEY)){
    localStorage.setItem(LS_ISSUED_KEY, JSON.stringify([]));
  }
}
seedData();

// ====================== HELPERS ======================
function getBooks(){ return JSON.parse(localStorage.getItem(LS_BOOKS_KEY) || "[]") }
function saveBooks(b){ localStorage.setItem(LS_BOOKS_KEY, JSON.stringify(b)) }
function getUsers(){ return JSON.parse(localStorage.getItem(LS_USERS_KEY) || "[]") }
function saveUsers(u){ localStorage.setItem(LS_USERS_KEY, JSON.stringify(u)) }
function getIssued(){ return JSON.parse(localStorage.getItem(LS_ISSUED_KEY) || "[]") }
function saveIssued(i){ localStorage.setItem(LS_ISSUED_KEY, JSON.stringify(i)) }
function escapeHtml(s){ return String(s).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;") }

// ====================== CUSTOM POPUP ======================
function showPopup(message) {
  // Remove existing popup if any
  const old = document.getElementById("custom-popup-overlay");
  if(old) old.remove();

  // Create overlay
  const overlay = document.createElement("div");
  overlay.id = "custom-popup-overlay";
  overlay.style.position = "fixed";
  overlay.style.top = 0;
  overlay.style.left = 0;
  overlay.style.width = "100%";
  overlay.style.height = "100%";
  overlay.style.background = "rgba(0,0,0,0.5)";
  overlay.style.display = "flex";
  overlay.style.justifyContent = "center";
  overlay.style.alignItems = "center";
  overlay.style.zIndex = 9999;

  // Create popup box
  const popup = document.createElement("div");
  popup.style.background = "#fff";
  popup.style.borderRadius = "8px";
  popup.style.padding = "20px 30px";
  popup.style.boxShadow = "0 5px 15px rgba(0,0,0,0.3)";
  popup.style.maxWidth = "400px";
  popup.style.textAlign = "center";
  popup.style.fontFamily = "Arial, sans-serif";

  popup.innerHTML = `
    <p style="margin-bottom:20px;">${message}</p>
    <button id="popup-close" style="padding:8px 15px; border:none; background:#333; color:#fff; border-radius:5px; cursor:pointer;">OK</button>
  `;

  overlay.appendChild(popup);
  document.body.appendChild(overlay);

  // Close popup on click
  document.getElementById("popup-close").addEventListener("click", () => overlay.remove());
}

// ====================== BOOK LIST ======================
if(document.getElementById("book-list")){
  renderBooks(getBooks());
  document.getElementById("search-btn").addEventListener("click", ()=>{
    const q = document.getElementById("book-search").value.trim().toLowerCase();
    const filtered = getBooks().filter(b => b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q));
    renderBooks(filtered);
  });
  document.getElementById("reset-btn").addEventListener("click", ()=>{
    document.getElementById("book-search").value="";
    renderBooks(getBooks());
  });
}

function renderBooks(list){
  const container = document.getElementById("book-list");
  if(!container) return;
  container.innerHTML = "";
  if(list.length === 0){ container.innerHTML = "<p>No books found.</p>"; return; }
  list.forEach(b=>{
    const card = document.createElement("div"); 
    card.className = "book-card";
    card.innerHTML = `<h4>${escapeHtml(b.title)}</h4><p>Author: ${escapeHtml(b.author)}</p><p>Category: ${escapeHtml(b.category || "N/A")}</p><p>Available: ${b.qty || 0}</p><button onclick="borrowBook(${b.id})">Borrow</button>`;
    container.appendChild(card);
  });
}

// ====================== BORROW BOOK ======================
function borrowBook(bookId){
  const currentUser = JSON.parse(sessionStorage.getItem("lms_current_user") || "null");
  if(!currentUser){
    if(confirm("You must be logged in to borrow. Go to login page?")) location.href="login.html";
    return;
  }
  const books = getBooks();
  const book = books.find(x=>x.id===bookId);
  if(!book || (book.qty || 0) <= 0){ showPopup("Book not available"); return; }

  book.qty = (book.qty || 0) - 1;
  saveBooks(books);

  const issued = getIssued();
  issued.push({id: Date.now(), userId: currentUser.id, bookId: book.id, bookTitle: book.title, date: (new Date()).toISOString().slice(0,10)});
  saveIssued(issued);

  showPopup("Book borrowed! Check Admin Issued Books to see record (demo).");
  renderBooks(getBooks());
}

// ====================== USER SIGNUP ======================
function userSignup() {
  const name = document.getElementById("signup-name").value.trim();
  const email = document.getElementById("signup-email").value.trim().toLowerCase();
  const password = document.getElementById("signup-password").value;

  if(!name || !email || !password) {
    showPopup("All fields are required");
    return;
  }

  const users = getUsers();
  if(users.find(u => u.email === email)) {
    showPopup("Email already registered");
    return;
  }

  const id = users.length ? Math.max(...users.map(u => u.id)) + 1 : 1;
  users.push({id, name, email, password});
  saveUsers(users);

  showPopup("Account created successfully! You can now log in.");
  setTimeout(()=> location.href = "login.html", 1000);
}

// ====================== USER LOGIN ======================
function userLogin(){
  const email = document.getElementById("login-email").value.trim().toLowerCase();
  const pass = document.getElementById("login-password").value;

  // ADMIN LOGIN
  if(email === "admin@example.com" && pass === "admin123"){
    sessionStorage.setItem("lms_current_user", JSON.stringify({
      id: 0, name: "Admin", email: "admin@example.com", isAdmin: true
    }));
    showPopup("Logged in as Admin");
    setTimeout(()=> location.href = "admin-dashboard.html", 1000);
    return;
  }

  // NORMAL USER LOGIN
  const users = getUsers();
  const u = users.find(x => x.email === email && x.password === pass);
  if(!u){
    showPopup("Invalid email or password");
    return;
  }

  sessionStorage.setItem("lms_current_user", JSON.stringify({
    id: u.id, name: u.name, email: u.email, isAdmin: false
  }));

  showPopup("Logged in as " + u.name);
  setTimeout(()=> location.href = "lms.html", 1000);
}

// ====================== FOOTER YEAR ======================
document.querySelectorAll("#year,#year2,#year3,#year4,#year5,#year6,#year7").forEach(el=>{
  if(el) el.textContent = new Date().getFullYear();
});




// ====================== HEADER UPDATE ======================
function updateHeader() {
  const headerRight = document.getElementById("header-right");
  if(!headerRight) return;

  const currentUser = JSON.parse(sessionStorage.getItem("lms_current_user") || "null");

  if(currentUser) {
    // replace login/signup with profile
    headerRight.innerHTML = `
      <div class="profile-wrapper">
        <div class="profile-icon">${currentUser.name[0].toUpperCase()}</div>
        <div class="profile-dropdown">
          <p><strong>${currentUser.name}</strong></p>
          <p>${currentUser.email}</p>
          <button id="logout-btn">Logout</button>
        </div>
      </div>
    `;

    const logoutBtn = document.getElementById("logout-btn");
    logoutBtn.addEventListener("click", () => {
      sessionStorage.removeItem("lms_current_user");
      location.reload();
    });

    const profileIcon = document.querySelector(".profile-icon");
    const dropdown = document.querySelector(".profile-dropdown");

    profileIcon.addEventListener("click", () => {
      dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
    });

    // hide dropdown if clicked outside
    document.addEventListener("click", e => {
      const wrapper = document.querySelector(".profile-wrapper");
      if(wrapper && !wrapper.contains(e.target)) {
        dropdown.style.display = "none";
      }
    });

  } else {
    // show login/signup if not logged in
    headerRight.innerHTML = `
      <a href="login.html" class="login-btn">Login</a>
      <a href="signup.html" class="signup-btn">Sign Up</a>
    `;
  }
}

// run on page load
// ====================== HEADER UPDATE ======================
function updateHeader() {
  const headerRight = document.getElementById("header-right");
  if(!headerRight) return;

  const currentUser = JSON.parse(sessionStorage.getItem("lms_current_user") || "null");

  if(currentUser) {
    // replace login/signup with profile
    headerRight.innerHTML = `
      <div class="profile-wrapper">
        <div class="profile-icon">${currentUser.name[0].toUpperCase()}</div>
        <div class="profile-dropdown">
          <p><strong>${currentUser.name}</strong></p>
          <p>${currentUser.email}</p>
          <button id="logout-btn">Logout</button>
        </div>
      </div>
    `;

    const logoutBtn = document.getElementById("logout-btn");
    logoutBtn.addEventListener("click", () => {
      // Send the user to the PHP file to update the database
      window.location.href = "logout.php";
    });

    const profileIcon = document.querySelector(".profile-icon");
    const dropdown = document.querySelector(".profile-dropdown");

    profileIcon.addEventListener("click", () => {
      dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
    });

    // hide dropdown if clicked outside
    document.addEventListener("click", e => {
      const wrapper = document.querySelector(".profile-wrapper");
      if(wrapper && !wrapper.contains(e.target)) {
        dropdown.style.display = "none";
      }
    });

  } else {
    // show login/signup if not logged in
    headerRight.innerHTML = `
      <a href="login.html" class="login-btn">Login</a>
      <a href="signup.html" class="signup-btn">Sign Up</a>
    `;
  }
}

// run on page load
window.addEventListener("load", updateHeader);

// ============ BOOK SLIDER (Working) ============
let currentIndex = 0;

const books = document.querySelectorAll(".carousel .book");
const nextBtn = document.getElementById("next");
const prevBtn = document.getElementById("prev");

function updateSlider() {
  books.forEach((book, index) => {
    book.classList.remove("active");

    if (index === currentIndex) {
      book.classList.add("active");
    }
  });
}

nextBtn?.addEventListener("click", () => {
  currentIndex = (currentIndex + 1) % books.length;
  updateSlider();
});

prevBtn?.addEventListener("click", () => {
  currentIndex = (currentIndex - 1 + books.length) % books.length;
  updateSlider();
});

// Auto Slide (every 3 seconds)
setInterval(() => {
  currentIndex = (currentIndex + 1) % books.length;
  updateSlider();
}, 3000);
