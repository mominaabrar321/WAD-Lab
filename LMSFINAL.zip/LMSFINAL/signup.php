<?php
// signup.php
include 'connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Clean the data to prevent database errors (Security fix)
    $name  = mysqli_real_escape_string($conn, trim($_POST['name'] ?? ''));
    $email = mysqli_real_escape_string($conn, trim($_POST['email'] ?? ''));
    $pass  = mysqli_real_escape_string($conn, trim($_POST['password'] ?? ''));

    // 1. Check for empty fields
    if (empty($name) || empty($email) || empty($pass)) {
        echo "All fields are required!";
        exit;
    }

    // 2. Check if email already exists
    $check = "SELECT user_id FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $check);

    if (mysqli_num_rows($result) > 0) {
        echo "<h3>Email already registered!</h3>";
        echo "<a href='signup.html'>Try again</a>";
        exit;
    }

    // 3. Insert new user
    $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$pass')";
    
    if (mysqli_query($conn, $sql)) {
        echo "<h3>Signup Successful!</h3>";
        echo "<p>Welcome, $name. <a href='login.html'>Click here to Login</a></p>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>