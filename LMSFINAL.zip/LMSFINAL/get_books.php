<?php
include "connect.php";

$sql = "SELECT * FROM books ORDER BY id DESC";
$result = mysqli_query($conn, $sql);

$books = [];

while ($row = mysqli_fetch_assoc($result)) {
    $books[] = $row;
}

echo json_encode($books);
?>