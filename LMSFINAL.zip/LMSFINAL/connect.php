<?php
// connect.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lmsfinal";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to handle special characters
$conn->set_charset("utf8");

// IMPORTANT: Do not echo anything here if successful!
?>