<?php
include "connect.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Books - Admin</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="admin-manage-books.css">
    <style>
        :root {
            --accent: #c47a42;
            --aside-bg: #e5d2bc;
            --aside-hover: #d9bea1;
            --aside-active: #c48d5b;
            --bg: #f6f6f6;
        }

        body {
            font-family: Segoe UI, Arial;
            background: var(--bg);
            margin: 0;
            color: #222;
        }

        .admin-layout {
            display: flex;
            min-height: 100vh;
        }

        .admin-aside {
            width: 210px;
            background: var(--aside-bg);
            padding: 18px;
            border-right: 1px solid #d8c4ac;
        }

        .admin-aside nav a {
            display: block;
            padding: 10px 12px;
            margin-bottom: 6px;
            color: #333;
            text-decoration: none;
            border-radius: 6px;
            transition: 0.3s;
        }

        .admin-aside nav a:hover {
            background: var(--aside-hover);
        }

        .admin-aside nav a.active {
            background: var(--aside-active);
            color: #fff;
        }

        .admin-main {
            flex: 1;
            padding: 24px;
        }

        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .btn-admin {
            padding: 8px 14px;
            background: var(--accent);
            color: white;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        .btn-admin:hover { background: rgb(179,107,59); }

        /* Table Styling */
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 16px;
            background: #fff;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }

        .admin-table th, .admin-table td {
            padding: 12px 14px;
            border: 1px solid #aaa; /* Column lines */
            text-align: center;
        }

        .admin-table thead th {
            background: var(--accent);
            color: #fff;
            font-weight: 600;
        }

        .admin-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .admin-table tbody tr:hover {
            background-color: #f2e0d0;
        }

        .book-img {
            width: 60px;
            height: 80px;
            object-fit: cover;
            border-radius: 4px;
        }

        .btn-edit {
            background: var(--accent);
            color: #fff;
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: 0.2s;
        }

        .btn-edit:hover { opacity: 0.85; }

        .btn-delete {
            background: #e74c3c;
            color: #fff;
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: 0.2s;
        }

        .btn-delete:hover { background: #c0392b; }
    </style>
</head>
<body>
<div class="admin-layout">

    <aside class="admin-aside">
        <h3>Admin</h3>
        <nav>
            <a href="admin-dashboard.php">Dashboard</a>
            <a href="admin-manage-books.php" class="active">Manage Books</a>
            <a href="admin-add-book.html">Add Book</a>
            <a href="admin-manage-users.php">Manage Users</a>
            <a href="admin-issued-books.html">Issued Books</a>
            <a href="lms.html" target="_blank">Open Site</a>
            <a href="logout.php" id="admin-logout">Logout</a>
        </nav>
    </aside>

    <main class="admin-main">
        <div class="admin-header">
            <h2>Manage Books</h2>
            <a href="admin-add-book.html" class="btn-admin">Add New Book</a>
        </div>

        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Category</th>
                    <th>Qty</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $query = "SELECT * FROM books ORDER BY id ASC";
            $result = mysqli_query($conn, $query);

            if ($result && mysqli_num_rows($result) > 0) {
                while ($book = mysqli_fetch_assoc($result)) {

                    $imgSrc = !empty($book['image']) && file_exists($book['image']) ? $book['image'] : 'images/logo.jpg';

                    echo "<tr>
                        <td>{$book['id']}</td>
                        <td><img src='{$imgSrc}' class='book-img'></td>
                        <td>{$book['title']}</td>
                        <td>{$book['author']}</td>
                        <td>{$book['category']}</td>
                        <td>{$book['qty']}</td>
                        <td>
                            <button class='btn-edit'>Edit</button>
                            <button class='btn-delete'>Delete</button>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No books found</td></tr>";
            }
            ?>
            </tbody>
        </table>
    </main>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const tbody = document.querySelector('.admin-table tbody');

    tbody.addEventListener('click', function(e) {
        const target = e.target;

        // Delete
        if(target.classList.contains('btn-delete')) {
            const row = target.closest('tr');
            const id = row.querySelector('td:first-child').innerText;
            if(confirm('Are you sure you want to delete this book?')) {
                fetch('admin_delete_book.php', {
                    method: 'POST',
                    headers: {'Content-Type':'application/x-www-form-urlencoded'},
                    body: 'id=' + id
                })
                .then(res => res.text())
                .then(res => {
                    if(res.trim() === 'success'){
                        row.remove();
                        alert('Book deleted successfully.');
                    } else {
                        alert('Failed to delete: ' + res);
                    }
                });
            }
        }

        // Edit
        if(target.classList.contains('btn-edit')) {
            const row = target.closest('tr');
            const id = row.querySelector('td:first-child').innerText;
            const title = row.children[2].innerText;
            const author = row.children[3].innerText;
            const category = row.children[4].innerText;
            const qty = row.children[5].innerText;

            const newTitle = prompt('Enter new title:', title);
            if(newTitle === null) return;
            const newAuthor = prompt('Enter new author:', author);
            if(newAuthor === null) return;
            const newCategory = prompt('Enter new category:', category);
            if(newCategory === null) return;
            const newQty = prompt('Enter new quantity:', qty);
            if(newQty === null) return;

            fetch('admin_edit_book.php', {
                method:'POST',
                headers:{'Content-Type':'application/x-www-form-urlencoded'},
                body: `id=${id}&title=${encodeURIComponent(newTitle)}&author=${encodeURIComponent(newAuthor)}&category=${encodeURIComponent(newCategory)}&qty=${encodeURIComponent(newQty)}`
            })
            .then(res => res.text())
            .then(res => {
                if(res.trim() === 'success'){
                    row.children[2].innerText = newTitle;
                    row.children[3].innerText = newAuthor;
                    row.children[4].innerText = newCategory;
                    row.children[5].innerText = newQty;
                    alert('Book updated successfully!');
                } else {
                    alert('Failed to update: ' + res);
                }
            });
        }
    });
});
</script>
</body>
</html>
