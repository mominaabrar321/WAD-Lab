<?php
session_start();
include "connect.php";

// Check if user is logged in
$logged_in = isset($_SESSION['user_id']);
$user_id = $logged_in ? $_SESSION['user_id'] : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Books - MyLibrary</title>
<link rel="stylesheet" href="lms.css">
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Segoe UI,Arial}
body{ background:#f8f4e7; color:#333; }
header{ background:#e6d2b3; padding:18px 40px; display:flex; justify-content:space-between; align-items:center; position:sticky; top:0; z-index:100; box-shadow:0 2px 5px rgba(0,0,0,0.1); }
.logo{ display:flex; align-items:center; gap:10px; }
.logo img{ width:35px; }
.logo h2{ font-weight:bold; color:#4a3b2d; font-size:22px; }
nav a{ margin-left:25px; text-decoration:none; color:#333; font-weight:500; font-size:17px; }
nav a:hover{ color:#8b5e34; }
.page-title{ text-align:center; margin:35px 0 15px; font-size:32px; font-weight:bold; color:#6b4423; }
.search-bar{ display:flex; justify-content:center; margin-bottom:25px; }
.search-bar input{ width:55%; padding:12px 18px; border-radius:12px; border:2px solid #d39764; background:white; font-size:16px; transition:.3s; }
.search-bar input:focus{ outline:none; border-color:#b97b44; box-shadow:0 0 6px rgba(185,123,68,.4); }
.categories{ display:flex; justify-content:center; gap:15px; margin-bottom:15px; flex-wrap:wrap; }
.category-btn, .btn-issued-books{ padding:10px 20px; border:none; border-radius:8px; background:#d39764; color:white; font-size:16px; cursor:pointer; transition:.3s; font-weight:bold; }
.category-btn:hover, .category-btn.active, .btn-issued-books:hover{ background:#b97b44; transform:translateY(-3px); }
#booksContainer{ display:flex; flex-wrap:wrap; gap:22px; justify-content:center; padding:0 40px; }
.book-card{ width:220px; background:white; padding:15px; border-radius:16px; box-shadow:0 4px 10px rgba(0,0,0,.18); text-align:center; transition:.3s; }
.book-card:hover{ transform:translateY(-6px); box-shadow:0 6px 14px rgba(0,0,0,.25); }
.book-card img{ width:100%; height:260px; object-fit:cover; border-radius:10px; }
.book-card h4{ font-size:18px; margin:12px 0 4px; color:#6b3f1c; font-weight:bold; }
.book-card p{ font-size:14px; color:#555; }
.issue-btn{ margin-top:12px; padding:9px 15px; background:#d39764; color:white; border:none; border-radius:7px; cursor:pointer; font-size:14px; font-weight:bold; transition:.3s; }
.issue-btn:hover{ background:#b97b44; transform:translateY(-3px); }
.issue-btn[disabled]{ background:#ccc; cursor:not-allowed; }
footer { text-align: center; padding: 20px; background: rgba(212, 178, 140, 0.5); color: black; margin-top: 40px; }
@media(max-width:768px){ .search-bar input{width:85%;} }

/* Modal styles */
.modal-overlay, #issuedModal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
.modal-box { background: white; padding: 25px; border-radius: 12px; width: 350px; text-align: center; box-shadow: 0 5px 15px rgba(0,0,0,0.3); max-height: 90%; overflow-y:auto; }
.modal-box h3 { margin-bottom: 15px; color: #6b4423; }
.modal-box table { width: 100%; border-collapse: collapse; margin-top:10px; }
.modal-box table th, .modal-box table td { border:1px solid #ccc; padding:6px; font-size:14px; text-align:left; }
.modal-box table th{ background:#d39764; color:white; }
.modal-btn { padding: 8px 16px; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; margin: 0 5px; }
.btn-confirm { background: #d39764; color: white; }
.btn-cancel { background: #ccc; color: #333; }
.overdue { color:red; font-weight:bold; font-size:13px; }
</style>
</head>
<body>

<header>
    <div class="logo">
        <img src="images/logo.jpg" alt="Logo">
        <h2>Crescent Library</h2>
    </div>
    <nav>
        <a href="lms.html">Home</a>
        <a href="books.php">Books</a>
        <a href="services.html">Services</a>
        <a href="about.html">About</a>
        <a href="contact.html">Contact</a>
    </nav>
</header>

<h1 class="page-title">Books</h1>

<?php if($logged_in): ?>
<div style="text-align:center;margin-bottom:15px;">
    <button class="btn-issued-books" onclick="openIssuedBooksModal()">My Issued Books</button>
</div>
<?php endif; ?>

<div class="search-bar">
    <input type="text" id="searchBar" placeholder="Search by title or author...">
</div>

<div class="categories">
    <button class="category-btn active" onclick="filterCategory('all', event)">All</button>
    <button class="category-btn" onclick="filterCategory('programming', event)">Programming</button>
    <button class="category-btn" onclick="filterCategory('design', event)">Design</button>
    <button class="category-btn" onclick="filterCategory('science', event)">Science</button>
    <button class="category-btn" onclick="filterCategory('novels', event)">Novels</button>
</div>

<div id="booksContainer">
<?php
$query = "SELECT * FROM books ORDER BY id DESC";
$result = mysqli_query($conn, $query);

// Fetch issued books for logged-in user
$issued_books = [];
if($logged_in){
    $issued_query = "SELECT ib.book_id, ib.due_date FROM issued_books ib WHERE ib.user_id=? AND ib.return_date IS NULL";
    $stmt = mysqli_prepare($conn, $issued_query);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $issued_result = mysqli_stmt_get_result($stmt);
    while($row = mysqli_fetch_assoc($issued_result)){
        $issued_books[$row['book_id']] = $row['due_date'];
    }
}

while($book = mysqli_fetch_assoc($result)){
    $title = $book['title'];
    $db_image = isset($book['image']) ? $book['image'] : "";
    $auto_image_jpg = "images/" . $title . ".jpg";
    $auto_image_jpeg = "images/" . $title . ".jpeg";

    if(file_exists($auto_image_jpg)){
        $final_image = $auto_image_jpg;
    } elseif(file_exists($auto_image_jpeg)){
        $final_image = $auto_image_jpeg;
    } elseif(!empty($db_image) && file_exists($db_image)){
        $final_image = $db_image;
    } else {
        $final_image = "images/logo.jpg";
    }

    echo "<div class='book-card'
        data-title='".htmlspecialchars($book['title'], ENT_QUOTES)."'
        data-author='".htmlspecialchars($book['author'], ENT_QUOTES)."'
        data-category='".htmlspecialchars($book['category'], ENT_QUOTES)."'>
        
        <img src='".htmlspecialchars($final_image, ENT_QUOTES)."' alt='Book Image'>
        <h4>".htmlspecialchars($book['title'])."</h4>
        <p>".htmlspecialchars($book['author'])."</p>
        <p style='margin-top:6px;font-weight:bold'>Available: ".(int)$book['qty']."</p>";

    $disabled = ((int)$book['qty'] <= 0 || isset($issued_books[$book['id']])) ? "disabled" : "";
    $button_text = isset($issued_books[$book['id']]) ? "Already Issued" : "Issue Book";

    if($logged_in){
        echo "<button class='issue-btn' $disabled onclick='openModal({$book['id']})'>$button_text</button>";
    } else {
        echo "<button class='issue-btn' $disabled onclick=\"window.location.href='login.html'\">Issue Book</button>";
    }

    echo "</div>";
}
?>
</div>

<!-- Issue Modal -->
<div id="issueModal" class="modal-overlay">
    <div class="modal-box">
        <h3>Select Duration</h3>
        <select id="daysSelect">
            <option value="7">7 Days</option>
            <option value="14">14 Days</option>
            <option value="21">21 Days</option>
            <option value="30">30 Days</option>
        </select>
        <div>
            <button class="modal-btn btn-confirm" onclick="confirmIssue()">Confirm</button>
            <button class="modal-btn btn-cancel" onclick="closeModal()">Cancel</button>
        </div>
    </div>
</div>

<!-- Issued Books Modal -->
<div id="issuedModal" class="modal-overlay">
    <div class="modal-box">
        <h3>My Issued Books</h3>
        <table>
            <thead>
                <tr>
                    <th>Book</th>
                    <th>Due Date</th>
                </tr>
            </thead>
            <tbody>
            <?php
            foreach($issued_books as $book_id => $due_date){
                $book_res = mysqli_query($conn, "SELECT title FROM books WHERE id=$book_id");
                $book_data = mysqli_fetch_assoc($book_res);
                $overdue = (strtotime($due_date) < time()) ? "<span class='overdue'>Overdue</span>" : "";
                echo "<tr>
                        <td>".htmlspecialchars($book_data['title'])."</td>
                        <td>$due_date $overdue</td>
                      </tr>";
            }
            if(empty($issued_books)){
                echo "<tr><td colspan='2'>No issued books</td></tr>";
            }
            ?>
            </tbody>
        </table>
        <div style="margin-top:10px;">
            <button class="modal-btn btn-cancel" onclick="closeIssuedBooksModal()">Close</button>
        </div>
    </div>
</div>

<footer>
    © 2025 MyLibrary – All Rights Reserved
</footer>

<script>
document.getElementById("searchBar").addEventListener("input", function(){
    let search = this.value.toLowerCase();
    let cards = document.querySelectorAll(".book-card");
    cards.forEach(card=>{
        let title = card.dataset.title.toLowerCase();
        let author = card.dataset.author.toLowerCase();
        card.style.display = (title.includes(search) || author.includes(search)) ? "block" : "none";
    });
});

function filterCategory(cat, ev){
    let cards = document.querySelectorAll(".book-card");
    cards.forEach(card=>{
        let category = card.dataset.category.toLowerCase();
        card.style.display = (cat === "all" || category === cat) ? "block" : "none";
    });
    document.querySelectorAll(".category-btn").forEach(btn=>btn.classList.remove("active"));
    ev.target.classList.add("active");
}

let selectedBookId = null;
function openModal(bookId) {
    selectedBookId = bookId;
    document.getElementById('issueModal').style.display = 'flex';
}
function closeModal() {
    document.getElementById('issueModal').style.display = 'none';
    selectedBookId = null;
}
function confirmIssue() {
    if(!selectedBookId) return;
    const days = document.getElementById('daysSelect').value;
    fetch("issue_book.php", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body: "book_id=" + encodeURIComponent(selectedBookId) + "&days=" + encodeURIComponent(days)
    })
    .then(res => res.json())
    .then(data => {
        alert(data.message);
        if(data.success){
            location.reload(); 
        }
        closeModal();
    })
    .catch(err => {
        console.error(err);
        alert("Network or server error");
        closeModal();
    });
}

// My Issued Books Modal
function openIssuedBooksModal(){
    document.getElementById('issuedModal').style.display = 'flex';
}
function closeIssuedBooksModal(){
    document.getElementById('issuedModal').style.display = 'none';
}
</script>
<script src="public-script.js"></script>
</body>
</html>
