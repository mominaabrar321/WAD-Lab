<?php
include "connect.php";

// ================= BOOKS COUNT =================
$result_books = mysqli_query($conn, "SELECT COUNT(*) AS total_books FROM books");
if(!$result_books) die("Error in books query: " . mysqli_error($conn));
$books = mysqli_fetch_assoc($result_books)['total_books'];

// ================= USERS COUNT =================
$result_users = mysqli_query($conn, "SELECT COUNT(*) AS total_users FROM users");
if(!$result_users) die("Error in users query: " . mysqli_error($conn));
$users = mysqli_fetch_assoc($result_users)['total_users'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Admin Dashboard - MyLibrary</title>
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <style>
    :root {
      --accent: #c47a42;
      --aside-bg: #e5d2bc;
      --aside-hover: #d9bea1;
      --aside-active: #c48d5b;
      --bg: #f6f6f6;
    }
    body { font-family: 'Segoe UI', Arial, sans-serif; background: var(--bg); margin:0; color:#222; }
    .admin-layout { display:flex; min-height:100vh; }
    .admin-aside { width:210px; background: var(--aside-bg); padding:18px; border-right:1px solid #d8c4ac; display:flex; flex-direction:column; }
    .admin-aside h3 { text-align:center; margin-bottom:20px; font-size:1.5rem; color:#333; }
    .admin-aside nav a { display:block; padding:10px 12px; margin-bottom:6px; text-decoration:none; color:#333; border-radius:6px; transition:0.3s; }
    .admin-aside nav a:hover { background: var(--aside-hover); }
    .admin-aside nav a.active { background: var(--aside-active); color:#fff; }

    /* Main */
    .admin-main {
      flex: 1;
      padding: 30px 40px;
    }

    .admin-header h2 {
      font-size: 1.8rem;
      margin-bottom: 20px;
    }

    /* Cards */
    .admin-cards {
      display: flex;
      gap: 20px;
      flex-wrap: wrap;
    }

    .admin-cards .card {
      flex: 1 1 200px;
      background: #fff;
      padding: 25px 20px;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
      text-align: center;
    }

    .admin-cards .card h3 {
      font-size: 2rem;
      margin-bottom: 8px;
      color: #c47a42;
    }

    .admin-cards .card p {
      font-size: 1rem;
      color: #555;
    }

    @media(max-width: 600px) {
      .admin-cards { flex-direction: column; gap: 15px; }
    }
  </style>
</head>
<body>
  <div class="admin-layout">
    <!-- Sidebar -->
    <aside class="admin-aside">
      <h3>Admin</h3>
      <nav>
        <a href="admin-dashboard.php" class="active">Dashboard</a>
        <a href="admin-manage-books.php">Manage Books</a>
        <a href="admin-add-book.html">Add Book</a>
        <a href="admin-manage-users.php">Manage Users</a>
        <a href="admin-issued-books.html">Issued Books</a>
        <a href="lms.html" target="_blank">Open Site</a>
        <a href="logout.php" id="admin-logout">Logout</a>
      </nav>
    </aside>

    <!-- Main -->
    <main class="admin-main">
      <header class="admin-header">
        <h2>Dashboard</h2>
      </header>

      <section class="admin-cards">
        <div class="card">
          <h3><?= $books ?></h3>
          <p>Total Books</p>
        </div>
        <div class="card">
          <h3><?= $users ?></h3>
          <p>Total Users</p>
        </div>
      </section>
    </main>
  </div>
</body>
</html>