<?php
include "connect.php";

$id = $_GET['id'];

// Fetch user by ID
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE user_id=$id"));
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
    <style>
        /* ===== Global ===== */
body {
    font-family: Arial, sans-serif;
    background-color: #f7f7f7;
    margin: 0;
    padding: 0;
}

h2 {
    text-align: center;
    margin-top: 30px;
    color: #333;
}

/* ===== Form Container ===== */
form {
    max-width: 400px;
    margin: 40px auto;
    padding: 30px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

/* ===== Input Fields ===== */
form label {
    display: block;
    margin-bottom: 6px;
    font-weight: bold;
    color: #555;
}

form input[type="text"],
form input[type="email"] {
    width: 100%;
    padding: 10px 12px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    transition: border 0.3s;
}

form input[type="text"]:focus,
form input[type="email"]:focus {
    border-color: #c47a42;
    outline: none;
}

/* ===== Button ===== */
form button {
    width: 100%;
    padding: 12px;
    background-color: #c47a42;
    color: #fff;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}

form button:hover {
    background-color: #a05c30;
}

/* ===== Responsive ===== */
@media (max-width: 480px) {
    form {
        padding: 20px;
        margin: 20px;
    }
}
    </style>
</head>
<body>

<h2>Edit User</h2>

<form method="POST" action="admin-update-user.php">
    <input type="hidden" name="id" value="<?= $user['user_id'] ?>">

    <label>Name:</label>
    <input type="text" name="name" value="<?= $user['name'] ?>" required><br><br>

    <label>Email:</label>
    <input type="email" name="email" value="<?= $user['email'] ?>" required><br><br>

    <button type="submit">Update User</button>
</form>

</body>
</html>