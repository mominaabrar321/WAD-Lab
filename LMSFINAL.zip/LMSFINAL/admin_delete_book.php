<?php
include "connect.php";

if (isset($_POST['id'])) {
    $id = (int)$_POST['id']; // Security: Cast to integer

    // 1. First, delete any 'issued' records associated with this book
    // This prevents the "Foreign Key Constraint" error
    mysqli_query($conn, "DELETE FROM issued_books WHERE book_id = $id");

    // 2. Now, delete the book itself
    $query = "DELETE FROM books WHERE id = $id";
    
    if (mysqli_query($conn, $query)) {
        echo "success";
    } else {
        // Send the actual error back to the browser
        echo "Error: " . mysqli_error($conn);
    }
}
?>